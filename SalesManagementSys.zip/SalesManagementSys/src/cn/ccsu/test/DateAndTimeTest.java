package cn.ccsu.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class DateAndTimeTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
