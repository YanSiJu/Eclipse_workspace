package cn.ccsu;

public enum Singleton {

}
