package cn.ccsu;

import org.junit.Test;
import org.springframework.stereotype.Controller;

@Controller
public class Main {

	public Main() {

	}

	public void display() {

	}

	@Test
	public void test() {

		System.out.println(2E2);
	}

}
