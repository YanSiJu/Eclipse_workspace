package cn.ccsu.service;

public interface IAdminService {

	boolean validateIdentify(String acc,String passwd);

}
