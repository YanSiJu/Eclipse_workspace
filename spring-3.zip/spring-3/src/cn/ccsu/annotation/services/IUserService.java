package cn.ccsu.annotation.services;

public interface IUserService {

	public void add();

}
