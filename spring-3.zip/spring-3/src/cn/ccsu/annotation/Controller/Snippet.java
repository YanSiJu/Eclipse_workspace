package cn.ccsu.annotation.Controller;

public class Snippet {
	public static void main(String[] args) {
//		cn.ccsu.annotation.Controller
	}
}

