package cn.ccsu.annotation.Repository;

import org.springframework.stereotype.Repository;

@Repository
public class UserRepository {

	public void respository() {

		System.out.println("UserRepository....");
	}
	
}
