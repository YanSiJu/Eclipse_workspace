package com.thinkgem.jeesite.common.beanvalidator;

/**
 * 默认Bean验证组
 * @author ThinkGem
 */
public interface DefaultGroup {

}
