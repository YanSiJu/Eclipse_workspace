/** Automatically generated file. DO NOT MODIFY */
package tjuci.dl.ui;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}