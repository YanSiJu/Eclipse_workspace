package cn.ccsu.mybatis.xml;

public class Snippet {
	public static void main(String[] args) {
//		cn.ccsu.mybatis.xml
	}
}

