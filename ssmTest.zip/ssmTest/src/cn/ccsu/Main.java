package cn.ccsu;

public class Main {

	public Main() {
		
	}

}
