package cn.ccsu.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.ccsu.bean.User;
import cn.ccsu.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService userService;

	public UserController() {
		System.out.println("UserController controller:" + this.getClass().getName());
	}

	@RequestMapping("/Testssm")
	public String login(Map<String, Object> map) {
		User user = userService.validateUser();
		map.put("user", user);
		return "login";
	}

}
