mui.plusReady(function(){
	var slider = mui('.mui-slider');
	slider.slider({interval:3000});
	
});