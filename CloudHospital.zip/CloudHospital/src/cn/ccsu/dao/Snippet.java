package cn.ccsu.dao;

public class Snippet {
	
	public static void main(String[] args) {
	
	}
}

