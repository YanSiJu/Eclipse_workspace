package cn.ccsu.bean;

public enum HospitalGrade {

}
