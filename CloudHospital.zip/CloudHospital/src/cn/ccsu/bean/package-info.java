/**
 * 
 */
/**
 * @author Bill
 *
 */
package cn.ccsu.bean;